package com.nothingisland

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.content.Intent

class IslandNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val text = extras.getCharSequence("android.text")?.toString().orEmpty()
        if (title.isNotBlank() || text.isNotBlank()) {
            sendBroadcast(Intent(IslandOverlayService.ACTION_NOTIFICATION).apply {
                setPackage(packageName)
                putExtra("title", title)
                putExtra("text", text)
            })
        }
    }
}
