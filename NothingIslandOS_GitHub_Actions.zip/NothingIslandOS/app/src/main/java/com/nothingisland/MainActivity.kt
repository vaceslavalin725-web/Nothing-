package com.nothingisland

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 10, 10)
    private val fg = Color.WHITE
    private val muted = Color.rgb(160, 160, 160)
    private val green = Color.rgb(112, 210, 115)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { addView(root) }

        root.addView(label("NOTHING", 30, fg, true))
        root.addView(label("ISLAND OS  •  CUSTOM EDITION", 12, green, true))
        root.addView(space(22))
        root.addView(label("Твой умный островок", 24, fg, true))
        root.addView(label("Минималистичный центр управления в стиле Nothing.", 14, muted))
        root.addView(space(22))

        val preview = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = rounded(Color.BLACK, dp(32), Color.DKGRAY, dp(1))
        }
        preview.addView(label("●   Клубный шум                         Ⅱ   ⌄", 16, fg, true))
        preview.addView(label("      Лил Трафик      ━━━━━●━━━━", 12, muted))
        root.addView(preview)
        root.addView(space(22))

        root.addView(section("НАСТРОЙКА ДОСТУПА"))
        root.addView(actionButton("①  Разрешить отображение поверх окон") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        root.addView(actionButton("②  Разрешить доступ к уведомлениям") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        if (Build.VERSION.SDK_INT >= 33) {
            root.addView(actionButton("③  Разрешить уведомления приложения") {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
            })
        }
        root.addView(space(18))
        root.addView(section("ЗАПУСК"))
        root.addView(actionButton("Запустить островок  ↗", green) {
            if (Settings.canDrawOverlays(this)) {
                val i = Intent(this, IslandOverlayService::class.java)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
            } else {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        root.addView(actionButton("Остановить островок") {
            stopService(Intent(this, IslandOverlayService::class.java))
        })
        root.addView(space(18))
        root.addView(section("ВОЗМОЖНОСТИ"))
        listOf(
            "Музыка — управление активной медиасессией",
            "Таймер — запуск и остановка прямо в островке",
            "Батарея — актуальный процент заряда",
            "Уведомления — последнее полученное уведомление",
            "Жесты — нажми на капсулу, чтобы раскрыть панель"
        ).forEach { root.addView(label("•  $it", 14, muted).apply { setPadding(0, dp(7), 0, dp(7)) }) }
        root.addView(space(24))
        root.addView(label("Подсказка: после выдачи доступов запусти островок. Для музыки включи доступ к уведомлениям и запусти воспроизведение.", 12, muted))
        setContentView(scroll)
    }

    private fun section(s: String) = label(s, 12, green, true).apply { setPadding(0, dp(0), 0, dp(10)) }
    private fun label(s: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size.toFloat(); setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }
    private fun actionButton(text: String, accent: Int = Color.rgb(35,35,35), click: () -> Unit) =
        Button(this).apply {
            this.text = text
            setTextColor(if (accent == green) Color.BLACK else fg)
            setBackgroundColor(accent)
            isAllCaps = false
            textSize = 14f
            setOnClickListener { click() }
            val p = LinearLayout.LayoutParams(-1, dp(52)); p.bottomMargin = dp(9)
            layoutParams = p
        }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int, stroke: Int, strokeWidth: Int) =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color); cornerRadius = radius.toFloat()
            setStroke(strokeWidth, stroke)
        }
}
