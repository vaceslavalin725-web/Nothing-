package com.nothingisland

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.session.MediaSessionManager
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import android.content.ComponentName
import android.content.pm.ServiceInfo
import java.util.concurrent.TimeUnit

class IslandOverlayService : Service() {
    companion object {
        const val ACTION_NOTIFICATION = "com.nothingisland.NEW_NOTIFICATION"
        private const val CHANNEL = "island_service"
    }

    private lateinit var wm: WindowManager
    private var island: LinearLayout? = null
    private var expanded = false
    private var timerSeconds = 0
    private var timerRunning = false
    private var latestTitle = "Nothing Island OS"
    private var latestText = "Готов к работе"
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            if (timerRunning && timerSeconds > 0) {
                timerSeconds--
                refresh()
                handler.postDelayed(this, 1000)
            } else if (timerRunning) {
                timerRunning = false
                latestTitle = "Таймер завершён"
                latestText = "Время вышло"
                refresh()
            }
        }
    }
    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) { refresh() }
    }
    private val notificationReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            latestTitle = intent?.getStringExtra("title") ?: latestTitle
            latestText = intent?.getStringExtra("text") ?: latestText
            refresh()
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Nothing Island OS работает")
            .setContentText("Островок отображается поверх приложений")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(7, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(7, notification)

        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        registerReceiver(notificationReceiver, IntentFilter(ACTION_NOTIFICATION), RECEIVER_NOT_EXPORTED)
        if (Settings.canDrawOverlays(this)) showOverlay()
    }

    private fun showOverlay() {
        if (island != null) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(10), dp(15), dp(10))
            background = shape(Color.BLACK, 36, Color.rgb(75,75,75), 1)
            elevation = dp(12).toFloat()
        }
        island = root
        refresh()
        val params = WindowManager.LayoutParams(
            dp(340), WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(28)
        }
        root.setOnClickListener { expanded = !expanded; refresh() }
        try { wm.addView(root, params) } catch (_: Exception) { island = null }
    }

    private fun refresh() {
        val root = island ?: return
        root.removeAllViews()
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        val dot = TextView(this).apply {
            text = "●"; textSize = 17f; setTextColor(Color.rgb(115, 220, 120))
            setPadding(0, 0, dp(10), 0)
        }
        row.addView(dot)
        val textCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        textCol.addView(txt(latestTitle, 14, Color.WHITE, true))
        textCol.addView(txt(latestText, 11, Color.LTGRAY, false))
        row.addView(textCol)
        val expand = txt(if (expanded) "⌃" else "⌄", 20, Color.WHITE, true).apply { setPadding(dp(8), 0, dp(4), 0) }
        row.addView(expand)
        root.addView(row)

        if (expanded) {
            val divider = View(this).apply { setBackgroundColor(Color.rgb(55,55,55)); layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(10); bottomMargin = dp(8) } }
            root.addView(divider)
            val media = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
            media.addView(smallButton("◀") { dispatchMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS) })
            media.addView(smallButton("Ⅱ / ▶") { dispatchMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) })
            media.addView(smallButton("▶|") { dispatchMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_NEXT) })
            root.addView(media)
            val timerRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            timerRow.addView(txt("ТАЙМЕР  ${formatTime(timerSeconds)}", 12, Color.WHITE, true).apply { layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
            timerRow.addView(smallButton("+1 мин") { timerSeconds += 60; refresh() })
            timerRow.addView(smallButton(if (timerRunning) "Стоп" else "Старт") {
                timerRunning = !timerRunning
                handler.removeCallbacks(tick)
                if (timerRunning) handler.post(tick)
                refresh()
            })
            root.addView(timerRow)
            val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val percent = if (level >= 0) (level * 100 / scale) else 0
            root.addView(txt("АККУМУЛЯТОР  $percent%", 11, Color.LTGRAY, false))
            root.addView(smallButton("Свернуть") { expanded = false; refresh() })
        }
    }

    private fun dispatchMediaKey(code: Int) {
        try {
            val manager = getSystemService(MEDIA_SESSION_SERVICE) as MediaSessionManager
            val sessions = manager.getActiveSessions(ComponentName(this, IslandNotificationListener::class.java))
            sessions.firstOrNull()?.dispatchMediaButtonEvent(android.view.KeyEvent(
                android.view.KeyEvent.ACTION_DOWN, code
            ))
        } catch (_: SecurityException) {
            latestText = "Разреши доступ к уведомлениям"
            refresh()
        } catch (_: Exception) {
            latestText = "Нет активного плеера"
            refresh()
        }
    }

    private fun smallButton(caption: String, action: () -> Unit) =
        TextView(this).apply {
            text = caption; textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = shape(Color.rgb(35,35,35), 20, Color.rgb(65,65,65), 1)
            setOnClickListener { action() }
            val p = LinearLayout.LayoutParams(-2, -2); p.setMargins(dp(3), dp(5), dp(3), dp(5)); layoutParams = p
        }

    private fun txt(s: String, size: Int, color: Int, bold: Boolean) =
        TextView(this).apply {
            text = s; textSize = size.toFloat(); setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            maxLines = 1
        }
    private fun shape(color: Int, radius: Int, stroke: Int, width: Int) =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(width), stroke) }
    private fun formatTime(sec: Int): String = String.format("%02d:%02d", sec / 60, sec % 60)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Island service", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (island == null && Settings.canDrawOverlays(this)) showOverlay()
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(notificationReceiver) } catch (_: Exception) {}
        island?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        island = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
